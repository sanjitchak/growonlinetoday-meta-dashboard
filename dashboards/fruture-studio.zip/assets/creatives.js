window.CREATIVE_DATA = [];
